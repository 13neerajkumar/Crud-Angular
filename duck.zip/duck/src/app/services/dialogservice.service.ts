import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddnewemployeeComponent } from '../components/addnewemployee/addnewemployee.component';

@Injectable({
  providedIn: 'root'
})
export class DialogserviceService {

  constructor(private dialog: MatDialog) { }

  openConfirmDialog(editval:Boolean,arr:any){
    return this.dialog.open(AddnewemployeeComponent,{
       width: '390px',
       panelClass: 'confirm-dialog-container',
       disableClose: true,
       position: { top: "10px" },
       data :{
         editval : editval,
         arr : arr
       }
     });
   }


}
