import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addnewemployee',
  templateUrl: './addnewemployee.component.html',
  styleUrls: ['./addnewemployee.component.css']
})
export class AddnewemployeeComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
  public dialogRef: MatDialogRef<AddnewemployeeComponent>) { }

  ngOnInit(): void {
    if(this.data.arr!='')
    {
      this.formData.empname = this.data.arr.empname;
      this.formData.dept = this.data.arr.dept;
      this.formData.salary = this.data.arr.salary;
    }
  }


  closeDialog() {
    this.dialogRef.close('000');
  }


  formData:any = [];

  addNew()
  {
      this.dialogRef.close(this.formData);
  }

}