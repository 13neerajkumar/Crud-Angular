import { Component, OnInit } from '@angular/core';
import { DialogserviceService } from 'src/app/services/dialogservice.service';

@Component({
  selector: 'app-employemanagement',
  templateUrl: './employemanagement.component.html',
  styleUrls: ['./employemanagement.component.css']
})
export class EmployemanagementComponent implements OnInit {

  constructor(private dialogservice:DialogserviceService) { }

  ngOnInit(): void {
  }

  searchPipe= '';

  allData:any=[
    {empname:'Neeraj',dept:'IT',salary:'100000'}
  ]

  openaddnewpop()
  {
    this.dialogservice.openConfirmDialog(false,'').afterClosed().subscribe((res)=>{
        if(res !='000')
        {
          this.allData.push({empname:res.empname,dept:res.dept,salary:res.salary});
        }
    });
  }

  edit(index)
  {
    this.dialogservice.openConfirmDialog(true,this.allData[index]).afterClosed().subscribe((res)=>{
      if(res !='000')
      {
        this.allData[index].empname = res.empname;
        this.allData[index].dept = res.dept;
        this.allData[index].salary = res.salary;
      }
  });
  }

  delete(index) {
    this.allData.splice(index, 1);
  }


  lowToHigh()
  {
    this.allData.sort((a: any, b: any) => {
      if (a.salary < b.salary) {
        return -1;
      } else if (a.salary > b.salary) {
        return 1;
      } else {
        return 0;
      }
    });
  }

}
