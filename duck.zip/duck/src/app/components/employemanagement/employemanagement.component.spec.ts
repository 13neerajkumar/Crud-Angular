import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployemanagementComponent } from './employemanagement.component';

describe('EmployemanagementComponent', () => {
  let component: EmployemanagementComponent;
  let fixture: ComponentFixture<EmployemanagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployemanagementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployemanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
